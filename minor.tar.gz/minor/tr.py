#!/usr/bin/python
import cgitb
cgitb.enable()
a=19
b=20
c=a+b
print (c)

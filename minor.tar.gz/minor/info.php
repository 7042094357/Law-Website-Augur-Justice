<?php
echo (phpinfo());
?>
